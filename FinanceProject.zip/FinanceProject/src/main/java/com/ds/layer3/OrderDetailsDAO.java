package com.ds.layer3;

import java.util.List;

import com.ds.layer2.OrderDetails;

public interface OrderDetailsDAO {
	OrderDetails selectOrder(int orderId);
	List<OrderDetails> selectCustomerOrders(int customerId);
	List<OrderDetails> selectAllOrders();
	
	void insertOrderDetails(OrderDetails orderDetails);
	void updateOrderDetails(OrderDetails orderDetails);
	void deleteOrderDetails(int orderId);
}
