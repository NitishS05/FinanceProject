package com.ds.layer2;

import java.util.Date;

public class EMICard {
	private long cardNo;
	private Date cardIssueDate;
	private int validityYears;
	private int remainingCredit;
	private String cardType;
	private int customerId;
	
	public long getCardNo() {
		return cardNo;
	}
	public Date getCardIssueDate() {
		return cardIssueDate;
	}
	public void setCardIssueDate(Date cardIssueDate) {
		this.cardIssueDate = cardIssueDate;
	}
	public int getValidityYears() {
		return validityYears;
	}
	public void setValidityYears(int validityYears) {
		this.validityYears = validityYears;
	}
	public int getRemainingCredit() {
		return remainingCredit;
	}
	public void setRemainingCredit(int remainingCredit) {
		this.remainingCredit = remainingCredit;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
}
