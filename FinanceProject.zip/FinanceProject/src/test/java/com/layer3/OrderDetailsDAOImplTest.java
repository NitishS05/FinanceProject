package com.layer3;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.ds.layer2.OrderDetails;
import com.ds.layer3.OrderDetailsDAOImpl;

public class OrderDetailsDAOImplTest {
	@Test
	public void testSelectOrderUsingOrderId() {
		OrderDetailsDAOImpl orderDAO = new OrderDetailsDAOImpl();
		Assertions.assertTrue(orderDAO!=null);
		
		OrderDetails order = orderDAO.selectOrder(1);
		Assertions.assertTrue(order!=null);
		System.out.println(order.toString());
	}
	
	@Test
	public void testSelectOrderUsingCustomerId() {
		OrderDetailsDAOImpl orderDAO = new OrderDetailsDAOImpl();
		Assertions.assertTrue(orderDAO!=null);
		
		List<OrderDetails> orders = orderDAO.selectCustomerOrders(1);
		Assertions.assertTrue(orders.size()!=0);
		
		for(OrderDetails order:orders) {
			System.out.println(order.toString());
		}
	}
	
	@Test
	public void testSelectAllOrders() {
		OrderDetailsDAOImpl orderDAO = new OrderDetailsDAOImpl();
		Assertions.assertTrue(orderDAO!=null);
		
		List<OrderDetails> orders = orderDAO.selectAllOrders();
		Assertions.assertTrue(orders.size()!=0);
		
		for(OrderDetails order:orders) {
			System.out.println(order.toString());
		}
	}
	
	@Test
	public void testInsertOrder() {
		OrderDetailsDAOImpl orderDAO = new OrderDetailsDAOImpl();
		Assertions.assertTrue(orderDAO!=null);
		
		OrderDetails order = new OrderDetails();
		Assertions.assertTrue(order!=null);
		
		order.setEmiPeriod(3);
		order.setOrderDate(Date.valueOf(LocalDate.now()));
		order.setCustomerId(1);
		order.setProductId(1);
		System.out.println(order.toString());
		
		orderDAO.insertOrderDetails(order);
	}
	
	@Test
	public void testUpdateOrder() {
		OrderDetailsDAOImpl orderDAO = new OrderDetailsDAOImpl();
		Assertions.assertTrue(orderDAO!=null);
		
		OrderDetails order = new OrderDetails();
		Assertions.assertTrue(order!=null);
		
		order.setOrderId(1);
		order.setEmiPeriod(12);
		order.setOrderDate(Date.valueOf(LocalDate.now()));
		order.setCustomerId(1);
		order.setProductId(1);
		System.out.println(order.toString());
		
		orderDAO.updateOrderDetails(order);
	}
	
	@Test
	public void testDeleteOrder() {
		OrderDetailsDAOImpl orderDAO = new OrderDetailsDAOImpl();
		Assertions.assertTrue(orderDAO!=null);
		
		orderDAO.deleteOrderDetails(1);
		if(orderDAO.selectOrder(1)==null)
			System.out.println("Order deleted....");
		else {
			System.out.println("Deletion Failed");
		}
	}
}
