package com.layer3;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.ds.layer2.EMICard;
import com.ds.layer3.EMICardDAOImpl;

public class EMICardDAOImplTest {
	
	@Test
	public void testSelectCard(){
		EMICardDAOImpl emiCardDAO = new EMICardDAOImpl();
		Assertions.assertTrue(emiCardDAO!=null);
		
		EMICard card = emiCardDAO.selectEMICard(1);
		Assertions.assertTrue(card!=null);
		System.out.println(card.toString());
	}
	
	@Test
	public void testSelectAllCard(){
		EMICardDAOImpl emiCardDAO = new EMICardDAOImpl();
		Assertions.assertTrue(emiCardDAO!=null);
		
		List<EMICard> cards = emiCardDAO.selectAllEMICards();
		Assertions.assertTrue(cards.size()!=0);
		
		for(EMICard card:cards) {
			System.out.println(card.toString());
		}
	}
	
	
	@Test
	public void testInsertCard(){
		EMICardDAOImpl emiCardDAO = new EMICardDAOImpl();
		Assertions.assertTrue(emiCardDAO!=null);
		
		EMICard card = new EMICard();
		Assertions.assertTrue(card!=null);
		card.setCardIssueDate(Date.valueOf(LocalDate.now()));
		card.setCardType("Gold");
		card.setCustomerId(1);
		card.setRemainingCredit(50000);
		card.setValidityYears(1);
		System.out.println(card);
		
		emiCardDAO.insertEMICard(card);
	}
	
	@Test
	public void testUpdateCard(){
		EMICardDAOImpl emiCardDAO = new EMICardDAOImpl();
		Assertions.assertTrue(emiCardDAO!=null);
		
		EMICard card = new EMICard();
		Assertions.assertTrue(card!=null);
		card.setCardNo(101022120000L);
		card.setCardIssueDate(Date.valueOf(LocalDate.now()));
		card.setCardType("Titanium");
		card.setCustomerId(1);
		card.setRemainingCredit(100000);
		card.setValidityYears(1);
		System.out.println(card);
		
		emiCardDAO.updateEMICard(card);
	}
	
	@Test
	public void testDeleteCard(){
		EMICardDAOImpl emiCardDAO = new EMICardDAOImpl();	
		Assertions.assertTrue(emiCardDAO!=null);
		
		emiCardDAO.deleteEMICard(1);
		if(emiCardDAO.selectEMICard(1)==null)
			System.out.println("Card deleted....");
		else {
			System.out.println("Deletion Failed");
		}
	}
}
